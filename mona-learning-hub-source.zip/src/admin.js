const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const since = days => new Date(Date.now() - days * 86400000).toISOString();

export function createTeacherDashboard({ root, supabase, courses, brand, signOut, base }) {
  let section = 'overview';
  let students = [], progress = [], controls = [], logins = [], star = null;
  let filter = '';
  let notice = '';
  let loading = false;
  let photoUrl = '';

  const activeStudents = () => students.filter(p => p.status === 'active' && p.last_seen_at && p.last_seen_at >= since(7));
  const answered = row => {
    const state = row.state || {};
    let total = 0;
    for (const value of Object.values(state)) {
      try {
        const parsed = typeof value === 'string' ? JSON.parse(value) : value;
        if (Number.isFinite(parsed)) total += parsed;
        else if (Number.isFinite(parsed?.solved)) total += parsed.solved;
        else if (Number.isFinite(parsed?.questionsAnswered)) total += parsed.questionsAnswered;
        else if (parsed && typeof parsed === 'object') {
          // Completed Grade 4 quizzes store one total for each lesson.
          total += Object.values(parsed).reduce((n, entry) => n + (Number.isFinite(entry?.total) ? entry.total : 0), 0);
        }
      } catch { /* Ignore an unrelated local storage value. */ }
    }
    return total;
  };
  const saveError = error => { notice = error?.message || String(error); render(); };
  async function refresh() {
    loading = true; render();
    const [a,b,c,d,e] = await Promise.all([
      supabase.from('student_profiles').select('user_id,student_name,grade,status,created_at,last_seen_at'),
      supabase.from('app_progress').select('user_id,app_id,state,updated_at'),
      supabase.from('course_controls').select('app_id,grade,visible,open_units,updated_at').order('grade'),
      supabase.from('student_logins').select('user_id,logged_at').gte('logged_at',since(30)),
      supabase.from('weekly_star').select('student_name,image_path,published,updated_at').eq('singleton',true).single(),
    ]);
    loading = false;
    const error = [a,b,c,d,e].find(r => r.error)?.error;
    if (error) { saveError(error); return; }
    const { data: role } = await supabase.from('teacher_admins').select('user_id');
    const teachers = new Set((role || []).map(r => r.user_id));
    students = (a.data || []).filter(p => !teachers.has(p.user_id));
    progress = b.data || []; controls = c.data || []; logins = d.data || []; star = e.data;
    if (star?.published && star.image_path) {
      const { data } = await supabase.storage.from('weekly-star').createSignedUrl(star.image_path, 3600);
      photoUrl = data?.signedUrl || '';
    } else photoUrl = '';
    render();
  }
  function shell(content) {
    root.innerHTML = `<div class="teacher-shell"><aside class="teacher-sidebar"><div class="teacher-logo">${brand()}</div><div class="teacher-sidebar-label">ADMINISTRATION</div><nav aria-label="Teacher sections">
      ${[['overview','◫','Dashboard'],['apps','▦','Apps & units'],['students','♙','Students'],['star','✦','Star of the week']].map(([id,icon,label]) => `<button data-section="${id}" class="${section===id?'selected':''}"><span>${icon}</span>${label}</button>`).join('')}</nav>
      <div class="teacher-sidebar-bottom"><div class="teacher-avatar">MH</div><div><b>Mrs. Mona Harb</b><small>Teacher administrator</small></div></div><button id="teacher-logout" class="teacher-logout">Log out ↗</button></aside>
      <main class="teacher-main"><header class="teacher-top"><div><span>ENGLISH LEARNING GARDEN</span><h1>${section==='overview'?'Dashboard':section==='apps'?'Apps & units':section==='students'?'Student accounts':'Star of the week'}</h1></div><div class="teacher-top-right"><span class="teacher-live">● Live data</span><button id="teacher-refresh" title="Refresh data">↻ Refresh</button></div></header>
      ${notice?`<div class="teacher-notice" role="status">${esc(notice)}</div>`:''}${loading?'<div class="teacher-loading">Loading dashboard…</div>':content}</main></div>`;
    root.querySelectorAll('[data-section]').forEach(b => b.onclick = () => { section = b.dataset.section; notice=''; render(); });
    root.querySelector('#teacher-logout').onclick = signOut;
    root.querySelector('#teacher-refresh').onclick = refresh;
  }
  function overview() {
    const active = activeStudents().length;
    const recent = new Set(logins.filter(l => l.logged_at >= since(7)).map(l => l.user_id));
    const rate = students.length ? Math.round(recent.size / students.length * 100) : 0;
    const q = progress.reduce((n,row) => n + answered(row),0);
    const cards = [
      ['Registered students',students.length,'Grade 3 & Grade 4','mint','♙'],
      ['Active students',active,'Visited in the last 7 days','cream','✦'],
      ['Questions answered',q,'Saved course activity','lavender','✎'],
      ['Login rate',`${rate}%`,'Students who logged in this week','aqua','↗'],
    ];
    return `<section class="teacher-hero"><div><span>WELCOME BACK, MRS. MONA ✦</span><h2>Your learning garden,<br>all in one place.</h2><p>See student activity and shape the next learning adventure.</p></div><div class="teacher-hero-art">A<span>✦</span>B<br><small>📚</small>C</div></section>
      <div class="teacher-metrics">${cards.map(([title,value,sub,color,icon])=>`<article class="teacher-metric ${color}"><div class="teacher-metric-top"><b>${title}</b><span>${icon}</span></div><strong>${value}</strong><small>${sub}</small></article>`).join('')}</div>
      <div class="teacher-columns"><section class="teacher-panel"><span class="teacher-kicker">QUICK ACTIONS</span><h2>Start here</h2><div class="teacher-actions"><button data-jump="students">Manage students <span>→</span></button><button data-jump="apps">Open app settings <span>→</span></button><button data-jump="star">Publish this week’s star <span>→</span></button></div></section>
      <section class="teacher-panel teacher-insight"><span class="teacher-kicker">THIS WEEK</span><h2>Learning at a glance</h2><p><b>${active}</b> active students out of <b>${students.length}</b> registered accounts.</p><div class="teacher-progress"><i style="width:${students.length?Math.min(100,Math.round(active/students.length*100)):0}%"></i></div><small>Active means a student opened the portal in the past 7 days.</small></section></div>`;
  }
  function apps() {
    return `<p class="teacher-intro">Choose which learning sites appear to students and which units they can open. Changes are saved immediately.</p><div class="teacher-app-grid">${courses.map(course=>{
      const row=controls.find(c=>c.app_id===course.id); const limit=course.id==='connectplus4-term1app'?5:6; const open=(row?.open_units || [1,2,3,4,5,6]).filter(n=>n<=limit);
      return `<article class="teacher-app-card"><div class="teacher-app-heading"><div class="teacher-app-icon ${course.color}">${course.icon}</div><div><small>GRADE ${course.grade} · ${esc(course.badge)}</small><h2>${esc(course.title)}</h2></div></div><label class="teacher-switch"><span>Show this app to students</span><input type="checkbox" data-visible="${esc(course.id)}" ${row?.visible?'checked':''}><i></i></label><div class="teacher-unit-label">OPEN UNITS <span>${open.length} / ${limit}</span></div><div class="teacher-units">${Array.from({length:limit},(_,i)=>i+1).map(n=>`<label class="teacher-unit ${open.includes(n)?'open':''}"><input type="checkbox" data-unit="${esc(course.id)}" value="${n}" ${open.includes(n)?'checked':''}><span>Unit ${n}</span></label>`).join('')}</div></article>`;}).join('')}</div>`;
  }
  function studentsView() {
    const selected = students.filter(p => (`${p.student_name} ${p.grade}`).toLowerCase().includes(filter.toLowerCase()));
    return `<div class="teacher-list-head"><div><p class="teacher-intro">Manage access and saved progress for each student.</p><b>${students.length} students</b></div><input id="student-search" type="search" placeholder="Search by name or grade…" value="${esc(filter)}" aria-label="Search students"></div>
      <div class="teacher-table-wrap"><table class="teacher-table"><thead><tr><th>Student</th><th>Grade</th><th>Status</th><th>Last activity</th><th>Actions</th></tr></thead><tbody>${selected.map(p=>`<tr><td><div class="teacher-student"><span>${esc(p.student_name.charAt(0))}</span><b>${esc(p.student_name)}</b></div></td><td>Grade ${p.grade}</td><td><span class="teacher-status ${p.status}">${p.status==='active'?'Active':'Suspended'}</span></td><td>${p.last_seen_at?new Date(p.last_seen_at).toLocaleDateString('en-GB'):'Not yet'}</td><td><div class="teacher-row-actions"><button data-student="${p.user_id}" data-action="${p.status==='active'?'suspend':'resume'}">${p.status==='active'?'Suspend':'Resume'}</button><button data-student="${p.user_id}" data-action="reset">Reset progress</button><button data-student="${p.user_id}" data-action="password">New password</button><button class="danger" data-student="${p.user_id}" data-action="delete">Delete</button></div></td></tr>`).join('') || '<tr><td colspan="5">No students found.</td></tr>'}</tbody></table></div>`;
  }
  function starView() {
    return `<div class="teacher-star-layout"><section class="teacher-panel"><span class="teacher-kicker">CELEBRATE A STUDENT</span><h2>Star of the week ✨</h2><p class="teacher-intro">Add a name and photo. Publish it to the student home page when ready.</p><form id="star-form"><label>Student name<input name="name" type="text" maxlength="80" required value="${esc(star?.student_name || '')}" placeholder="Student’s name"></label><label>Photo (JPG, PNG or WebP, up to 5 MB)<input name="photo" type="file" accept="image/jpeg,image/png,image/webp"></label><label class="teacher-publish"><input name="published" type="checkbox" ${star?.published?'checked':''}> Show on student home pages</label><button class="teacher-save" type="submit">Save star of the week →</button></form></section><section class="teacher-star-preview"><span>STUDENT HOME PAGE PREVIEW</span><div class="teacher-star-card">${photoUrl?`<img src="${esc(photoUrl)}" alt="Star of the week">`:'<div class="teacher-star-placeholder">★</div>'}<div><small>✦ STAR OF THE WEEK</small><h2>${esc(star?.student_name || 'Your shining star')}</h2><p>Keep shining and inspiring us all!</p></div></div><small>${star?.published?'Published for students':'Draft — visible only to you'}</small></section></div>`;
  }
  function render() {
    shell(section==='overview'?overview():section==='apps'?apps():section==='students'?studentsView():starView());
    root.querySelectorAll('[data-jump]').forEach(b=>b.onclick=()=>{section=b.dataset.jump;render();});
    root.querySelectorAll('[data-visible]').forEach(b=>b.onchange=()=>updateControl(b.dataset.visible,{visible:b.checked}));
    root.querySelectorAll('[data-unit]').forEach(b=>b.onchange=()=>{
      const row=controls.find(c=>c.app_id===b.dataset.unit);
      const units=new Set(row?.open_units || [1,2,3,4,5,6]);
      b.checked?units.add(Number(b.value)):units.delete(Number(b.value));
      updateControl(b.dataset.unit,{open_units:[...units].sort()});
    });
    const search=root.querySelector('#student-search');
    if(search) search.oninput=()=>{filter=search.value;const start=search.selectionStart;render();const next=root.querySelector('#student-search');next.focus();next.setSelectionRange(start,start);};
    root.querySelectorAll('[data-action]').forEach(b=>b.onclick=()=>studentAction(b.dataset.student,b.dataset.action));
    const form=root.querySelector('#star-form'); if(form) form.onsubmit=saveStar;
  }
  async function updateControl(id,patch) {
    const { error }=await supabase.from('course_controls').update({...patch,updated_at:new Date().toISOString()}).eq('app_id',id);
    if(error) return saveError(error);
    notice='App settings saved.'; await refresh();
  }
  async function studentAction(id,action) {
    const p=students.find(s=>s.user_id===id); if(!p) return;
    const name=p.student_name;
    if(action==='suspend'||action==='resume') {
      if(!confirm(`${action==='suspend'?'Suspend':'Resume'} ${name}’s account?`)) return;
      const {error}=await supabase.from('student_profiles').update({status:action==='suspend'?'suspended':'active'}).eq('user_id',id);
      if(error) return saveError(error); notice=`${name}’s account ${action==='suspend'?'suspended':'resumed'}.`; return refresh();
    }
    if(action==='reset') {
      if(!confirm(`Reset all saved progress for ${name}? This cannot be undone.`)) return;
      const {error}=await supabase.rpc('teacher_reset_student_progress',{target_user:id});
      if(error) return saveError(error); notice=`${name}’s saved progress was reset.`; return refresh();
    }
    if(action==='password') {
      const password=prompt(`Enter a temporary password for ${name} (at least 8 characters). Share it privately with the student.`);
      if(password===null) return;
      if(password.length<8) {notice='The temporary password must have at least 8 characters.';return render();}
      const {error}=await supabase.functions.invoke('teacher-admin',{body:{action:'password',userId:id,password}});
      if(error) return saveError(error); notice=`Temporary password changed for ${name}. Share it privately.`; return render();
    }
    if(action==='delete') {
      if(!confirm(`Permanently delete ${name}’s account and saved progress?`)) return;
      const {error}=await supabase.functions.invoke('teacher-admin',{body:{action:'delete',userId:id}});
      if(error) return saveError(error); notice=`${name}’s account was deleted.`; return refresh();
    }
  }
  async function saveStar(event) {
    event.preventDefault();
    const form=new FormData(event.currentTarget);
    const name=String(form.get('name')||'').trim(); const photo=form.get('photo');
    let path=star?.image_path || null;
    if(!name) {notice='Enter the student name.';return render();}
    if(photo?.size) {
      if(photo.size>5*1024*1024 || !['image/jpeg','image/png','image/webp'].includes(photo.type)) {notice='Choose a JPG, PNG or WebP photo up to 5 MB.';return render();}
      const ext=photo.type==='image/jpeg'?'jpg':photo.type==='image/png'?'png':'webp';
      path=`star-${crypto.randomUUID()}.${ext}`;
      const {error}=await supabase.storage.from('weekly-star').upload(path,photo,{contentType:photo.type});
      if(error) return saveError(error);
    }
    const {error}=await supabase.from('weekly_star').update({student_name:name,image_path:path,published:form.has('published'),updated_at:new Date().toISOString()}).eq('singleton',true);
    if(error) return saveError(error);
    if (photo?.size && star?.image_path && star.image_path !== path) {
      await supabase.storage.from('weekly-star').remove([star.image_path]);
    }
    if (photo?.size && star?.image_path && star.image_path !== path) {
      await supabase.storage.from('weekly-star').remove([star.image_path]);
    }
    notice='Star of the week saved.'; await refresh();
  }
  return { refresh, render };
}
