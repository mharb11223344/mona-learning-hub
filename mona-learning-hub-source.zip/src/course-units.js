// Persisted controls keep the same IDs when a textbook changes display order.
export function courseUnits(courseId) {
  if (courseId === 'Plus4app-term1') return [
    { id: 1, label: 'Unit 1 · What Can I Do?' },
    { id: 2, label: 'Unit 2 · Plants and Animals' },
    { id: 3, label: 'Unit 3 · My World' },
    { id: 5, label: 'Unit 4 · Resources in Our World' },
    { id: 6, label: 'Unit 5 · Let’s Work' },
  ];
  return Array.from({ length: courseId === 'connectplus4-term1app' ? 5 : 6 }, (_, index) => ({ id: index + 1, label: `Unit ${index + 1}` }));
}
