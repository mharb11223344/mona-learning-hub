import { createClient } from '@supabase/supabase-js';
import './style.css';

const BASE = import.meta.env.BASE_URL;
const SUPABASE_URL = 'https://hdoyfcorsrbjfbnunbvh.supabase.co';
// A publishable browser key is safe to expose. Never place a secret/service key here.
const SUPABASE_KEY = 'sb_publishable_Bg6pEfKsoqazhUs_K4kRCw_P95XEehc';
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
});

const COURSES = [
  { id: 'english3-1termapp', grade: 3, title: 'English Primary 3', subtitle: 'Explore the English Garden', badge: 'English', icon: '📖', color: 'pink', keys: ['monaPrimary3AppV1'] },
  { id: 'connectplus3-term1app', grade: 3, title: 'Connect Plus 3', subtitle: 'Your Connect Plus adventure', badge: 'Connect Plus', icon: '🚀', color: 'blue', keys: ['connectPlus3MonaHarbV2'] },
  { id: 'connectplus4-term1app', grade: 4, title: 'English Primary 4', subtitle: 'Explore the English Garden', badge: 'English', icon: '📚', color: 'violet', keys: ['mona-primary4-profile-v1', 'mona-primary4-progress-v1'] },
  { id: 'Plus4app-term1', grade: 4, title: 'Connect Plus 4', subtitle: 'Your Connect Plus adventure', badge: 'Connect Plus', icon: '✨', color: 'peach', keys: ['connect-plus-student', 'connect-plus-progress', 'connect-plus-quiz-checkpoint'] },
];
const ALL_KEYS = COURSES.flatMap(course => course.keys);
const LEGACY_BACKUP_KEY = 'mona-learning-hub-local-backup-v1';
const app = document.getElementById('app');
let user = null;
let profile = null;
let mode = 'login';
let currentCourse = null;
let courseRows = new Map();
let legacy = new Map();
let saveTimer = null;
let busy = false;
let message = '';
let messageType = 'info';

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}

function image(path) { return `${BASE}${path}`; }
function coursesForGrade(grade) { return COURSES.filter(course => course.grade === grade); }
function courseUrl(course) { return `${location.origin}/${encodeURIComponent(course.id)}/`; }
function setMessage(value, type = 'info') { message = value; messageType = type; render(); }

function snapshot(course) {
  const data = {};
  for (const key of course.keys) {
    const value = localStorage.getItem(key);
    if (value !== null) data[key] = value;
  }
  return data;
}

function clearCourseKeys() {
  for (const key of ALL_KEYS) localStorage.removeItem(key);
}

function backupPreviousProgress() {
  let backup = {};
  try { backup = JSON.parse(localStorage.getItem(LEGACY_BACKUP_KEY) || '{}') || {}; }
  catch { backup = {}; }
  for (const course of COURSES) {
    const state = snapshot(course);
    if (!backup[course.id] && Object.keys(state).length) backup[course.id] = state;
  }
  try { localStorage.setItem(LEGACY_BACKUP_KEY, JSON.stringify(backup)); }
  catch { /* The original course keys remain available if storage is full. */ }
  return backup;
}

function seedProfile(course) {
  if (!profile) return;
  const student = profile.student_name;
  const grade = `Primary ${profile.grade}`;
  if (course.id === 'english3-1termapp') localStorage.setItem(course.keys[0], JSON.stringify({ student, className: grade }));
  if (course.id === 'connectplus3-term1app') localStorage.setItem(course.keys[0], JSON.stringify({ student, className: grade }));
  if (course.id === 'connectplus4-term1app') localStorage.setItem(course.keys[0], JSON.stringify({ name: student, className: grade, school: 'Al Andalus Private Schools', avatar: '👧🏽' }));
  if (course.id === 'Plus4app-term1') localStorage.setItem(course.keys[0], JSON.stringify({ name: student, className: grade, school: 'Al Andalus Private Schools' }));
}

async function loadAccount() {
  const { data: authData, error: authError } = await supabase.auth.getUser();
  if (authError || !authData.user) {
    user = null; profile = null; currentCourse = null; render(); return;
  }
  user = authData.user;
  const { data: student, error: profileError } = await supabase
    .from('student_profiles').select('student_name,grade').eq('user_id', user.id).single();
  if (profileError || !student) {
    profile = null;
    setMessage('We could not load your student profile. Please contact Mrs. Mona Harb if this continues.', 'error');
    return;
  }
  profile = student;
  const { data: rows, error: rowsError } = await supabase
    .from('app_progress').select('app_id,state,updated_at').eq('user_id', user.id);
  if (rowsError) {
    setMessage('We could not load your saved progress. Please refresh the page.', 'error');
    return;
  }
  courseRows = new Map((rows ?? []).map(row => [row.app_id, row]));
  const previous = backupPreviousProgress();
  legacy = new Map(coursesForGrade(profile.grade).map(course => [course.id, previous[course.id] || {}]));
  clearCourseKeys();
  message = '';
  render();
}

async function saveCourse(course) {
  if (!user || !profile || course.grade !== profile.grade) return false;
  const state = snapshot(course);
  const { error } = await supabase.from('app_progress').upsert({
    user_id: user.id, app_id: course.id, state, updated_at: new Date().toISOString(),
  }, { onConflict: 'user_id,app_id' });
  if (error) {
    updateSaveBadge('Could not save. Check your connection.');
    message = 'Your progress could not be saved. Check your internet connection before leaving the lesson.';
    messageType = 'error';
    return false;
  }
  courseRows.set(course.id, { app_id: course.id, state, updated_at: new Date().toISOString() });
  updateSaveBadge('Progress saved ✓');
  return true;
}

function updateSaveBadge(value) {
  const node = document.querySelector('#save-status');
  if (node) node.textContent = value;
}

function queueSave() {
  if (!currentCourse) return;
  updateSaveBadge('Saving progress...');
  clearTimeout(saveTimer);
  const course = currentCourse;
  saveTimer = setTimeout(() => { if (currentCourse?.id === course.id) void saveCourse(course); }, 350);
}

window.addEventListener('storage', event => {
  if (currentCourse && currentCourse.keys.includes(event.key)) queueSave();
});
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden' && currentCourse) {
    clearTimeout(saveTimer);
    void saveCourse(currentCourse);
  }
});

async function closeCourse() {
  if (!currentCourse) return;
  const course = currentCourse;
  clearTimeout(saveTimer);
  const frame = document.querySelector('#course-frame');
  if (frame) frame.remove();
  await saveCourse(course);
  currentCourse = null;
  clearCourseKeys();
  render();
}

async function openCourse(id) {
  const course = COURSES.find(item => item.id === id);
  if (!course || !profile || course.grade !== profile.grade) return;
  if (currentCourse) await closeCourse();
  clearCourseKeys();
  const row = courseRows.get(course.id);
  if (row?.state && typeof row.state === 'object') {
    for (const key of course.keys) {
      const value = row.state[key];
      if (typeof value === 'string') localStorage.setItem(key, value);
    }
  } else {
    seedProfile(course);
  }
  currentCourse = course;
  message = '';
  render();
}

async function importLegacy(id) {
  const course = COURSES.find(item => item.id === id);
  const state = legacy.get(id);
  if (!course || !state || !profile || course.grade !== profile.grade || courseRows.has(id)) return;
  clearCourseKeys();
  for (const [key, value] of Object.entries(state)) if (course.keys.includes(key)) localStorage.setItem(key, value);
  const saved = await saveCourse(course);
  clearCourseKeys();
  if (saved) { legacy.delete(id); render(); }
}

async function signOut() {
  if (currentCourse) await closeCourse();
  await supabase.auth.signOut();
  clearCourseKeys();
  user = null; profile = null; currentCourse = null; courseRows.clear(); legacy.clear();
  mode = 'login'; message = ''; render();
}

function brand() {
  return `<div class="brand"><span class="brand-mark"><img src="${image('school-logo.png')}" alt="Al Andalus Private Schools logo" /></span><span class="brand-name"><b>Al Andalus Private Schools</b><small>ENGLISH LEARNING GARDEN</small></span></div>`;
}

function notice() { return message ? `<div class="notice ${messageType}" role="status">${escapeHtml(message)}</div>` : ''; }

function renderAuth() {
  app.innerHTML = `<main class="auth-shell">
    <section class="auth-content">
      <header class="site-header">${brand()}<span class="teacher-pill">With <b>Mrs. Mona Harb</b> ✦</span></header>
      <div class="auth-copy"><span class="eyebrow"><span>✦</span> ENGLISH GARDEN · TERM 1</span>
        <h1>Your <em>English</em> adventure<br>starts here!</h1>
        <p>A world of stories, words and joyful challenges, made for Grade 3 and Grade 4 girls.</p>
      </div>
      <div class="auth-card">
        <div class="auth-tabs" role="tablist"><button id="login-tab" class="${mode === 'login' ? 'active' : ''}" type="button">Log in</button><button id="signup-tab" class="${mode === 'signup' ? 'active' : ''}" type="button">Create account</button></div>
        <div class="auth-card-head"><span class="sparkle">✿</span><div><h2>${mode === 'signup' ? 'Join our garden' : 'Welcome back!'}</h2><p>${mode === 'signup' ? 'A few details, then your adventure begins' : 'Open your lessons and saved progress'}</p></div></div>
        ${notice()}
        <form id="auth-form">
          ${mode === 'signup' ? `<label for="student-name">Student name</label><input id="student-name" name="student_name" type="text" autocomplete="name" maxlength="80" minlength="2" placeholder="Your name" required />
          <label for="grade">Grade</label><div class="grade-select"><select id="grade" name="grade" required><option value="" selected disabled>Choose your grade</option><option value="3">Grade 3</option><option value="4">Grade 4</option></select><span>⌄</span></div>` : ''}
          <label for="email">Email address</label><input id="email" name="email" type="email" autocomplete="email" inputmode="email" placeholder="name@example.com" required />
          <label for="password">Password</label><input id="password" name="password" type="password" autocomplete="${mode === 'signup' ? 'new-password' : 'current-password'}" minlength="6" placeholder="At least 6 characters" required />
          <button class="primary-btn" type="submit" ${busy ? 'disabled' : ''}>${busy ? 'Just a moment...' : mode === 'signup' ? 'Create my account  →' : 'Enter my garden  →'}</button>
        </form>
        <p class="form-foot">${mode === 'signup' ? 'Already have an account? <button id="switch-login" type="button">Log in</button>' : 'New here? <button id="switch-signup" type="button">Create an account</button>'}</p>
      </div>
      <div class="auth-bottom"><span>✦ Learn your way</span><span>✦ Save your progress</span><span>✦ Made for you</span></div>
    </section>
    <section class="auth-visual" aria-label="Egyptian girls discovering English"><img src="${image('english-hero.png')}" alt="Three young Egyptian girls discovering English through a storybook" /></section>
  </main>`;
  document.querySelector('#login-tab').onclick = () => { mode = 'login'; message = ''; render(); };
  document.querySelector('#signup-tab').onclick = () => { mode = 'signup'; message = ''; render(); };
  document.querySelector('#switch-login')?.addEventListener('click', () => { mode = 'login'; message = ''; render(); });
  document.querySelector('#switch-signup')?.addEventListener('click', () => { mode = 'signup'; message = ''; render(); });
  document.querySelector('#auth-form').addEventListener('submit', submitAuth);
}

async function submitAuth(event) {
  event.preventDefault();
  if (busy) return;
  const form = new FormData(event.currentTarget);
  const email = String(form.get('email') ?? '').trim();
  const password = String(form.get('password') ?? '');
  busy = true; message = ''; render();
  try {
    if (mode === 'signup') {
      const name = String(form.get('student_name') ?? '').trim();
      const grade = Number(form.get('grade'));
      if (name.length < 2 || ![3, 4].includes(grade)) throw new Error('Enter your name and choose Grade 3 or Grade 4.');
      const { data, error } = await supabase.auth.signUp({ email, password, options: {
        data: { student_name: name, grade: String(grade) },
        emailRedirectTo: `${location.origin}${BASE}`,
      } });
      if (error) throw error;
      if (data.session) await loadAccount();
      else { mode = 'login'; setMessage('Account created. Please check your email for a confirmation link, then log in.', 'success'); }
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      await loadAccount();
    }
  } catch (error) {
    const text = String(error?.message ?? error);
    setMessage(text.includes('Invalid login') ? 'The email address or password is incorrect.' :
      text.includes('Email not confirmed') ? 'Please confirm your email address first.' : text, 'error');
  } finally { busy = false; render(); }
}

function card(course) {
  const row = courseRows.get(course.id);
  const oldState = legacy.get(course.id);
  const canImport = !row && oldState && Object.keys(oldState).length > 0;
  return `<article class="course-card ${course.color}"><div class="course-top"><span class="course-icon">${course.icon}</span><span class="course-tag">${course.badge}</span></div>
    <div class="course-copy"><h3>${course.title}</h3><p>${course.subtitle}</p></div>
    <div class="course-bottom"><span class="saved-state">${row ? '✓ Progress saved' : 'A new adventure'}</span><button type="button" class="course-open" data-course="${escapeHtml(course.id)}">${row ? 'Continue learning' : 'Start learning'} <span>→</span></button></div>
    ${canImport ? `<button type="button" class="import-link" data-import="${escapeHtml(course.id)}">Have progress on this device? Import it</button>` : ''}
  </article>`;
}

function renderDashboard() {
  const courses = coursesForGrade(profile.grade);
  app.innerHTML = `<main class="dashboard"><header class="dash-header"><div class="dash-inner">${brand()}<div class="dash-user"><span class="user-avatar">${escapeHtml(profile.student_name.charAt(0))}</span><div><b>${escapeHtml(profile.student_name)}</b><small>Grade ${profile.grade}</small></div><button id="logout" type="button">Log out</button></div></div></header>
    <div class="dash-wrap"><section class="welcome-panel"><div><span class="eyebrow">✦ HELLO, SUPERSTAR!</span><h1>Welcome, ${escapeHtml(profile.student_name)} <span>👋</span></h1><p>Choose your adventure and pick up where you left off.</p><span class="grade-badge">⭐ Grade ${profile.grade}</span></div><div class="welcome-doodle" aria-hidden="true">A<span>✦</span>B<br><small>📚</small>C</div></section>
    ${notice()}<div class="section-heading"><div><span>✦ YOUR LEARNING PATH</span><h2>Your learning sites</h2></div><p>Two sites chosen for your grade</p></div>
    <section class="course-grid">${courses.map(card).join('')}</section><div class="dash-footer"><span>Al Andalus Private Schools</span><span>Made with care by Mrs. Mona Harb ♡</span></div></div></main>`;
  document.querySelector('#logout').onclick = signOut;
  document.querySelectorAll('[data-course]').forEach(button => button.onclick = () => openCourse(button.dataset.course));
  document.querySelectorAll('[data-import]').forEach(button => button.onclick = () => importLegacy(button.dataset.import));
}

function renderPlayer() {
  const course = currentCourse;
  app.innerHTML = `<main class="player"><header class="player-bar"><button id="back" type="button">← Back to my sites</button><div><strong>${escapeHtml(course.title)}</strong><small>Mrs. Mona Harb · Grade ${profile.grade}</small></div><span id="save-status">Your progress saves automatically</span></header><iframe id="course-frame" title="${escapeHtml(course.title)}" src="${courseUrl(course)}" allow="fullscreen; clipboard-read; clipboard-write"></iframe></main>`;
  document.querySelector('#back').onclick = closeCourse;
}

function render() {
  if (!user || !profile) renderAuth();
  else if (currentCourse) renderPlayer();
  else renderDashboard();
}

supabase.auth.onAuthStateChange((event) => {
  if (event === 'SIGNED_OUT') { user = null; profile = null; currentCourse = null; clearCourseKeys(); render(); }
});

render();
loadAccount().catch(error => setMessage(`Could not connect to the database: ${error.message}`, 'error'));
