import { createClient } from '@supabase/supabase-js';
import { createTeacherDashboard } from './admin.js';
import { hasLearningProgress, mergeProgress } from './progress-state.js';
import './style.css';
import './teacher.css';

const BASE = import.meta.env.BASE_URL;
const SUPABASE_URL = 'https://hdoyfcorsrbjfbnunbvh.supabase.co';
// A publishable browser key is safe to expose. Never place a secret/service key here.
const SUPABASE_KEY = 'sb_publishable_Bg6pEfKsoqazhUs_K4kRCw_P95XEehc';
const supabase = createClient(SUPABASE_URL, SUPABASE_KEY, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
});

const COURSES = [
  { id: 'english3-1termapp', grade: 3, title: 'English Primary 3', subtitle: 'Explore the English Garden', badge: 'English', icon: '📖', color: 'pink', keys: ['monaPrimary3AppV1'] },
  { id: 'connectplus3-term1app', grade: 3, title: 'Connect Plus 3', subtitle: 'Your Connect Plus adventure', badge: 'Connect Plus', icon: '🚀', color: 'blue', keys: ['connectPlus3MonaHarbV2'] },
  { id: 'connectplus4-term1app', grade: 4, title: 'English Primary 4', subtitle: 'Explore the English Garden', badge: 'English', icon: '📚', color: 'violet', keys: ['mona-primary4-profile-v1', 'mona-primary4-progress-v1'] },
  { id: 'Plus4app-term1', grade: 4, title: 'Connect Plus 4', subtitle: 'Your Connect Plus adventure', badge: 'Connect Plus', icon: '✨', color: 'peach', keys: ['connect-plus-student', 'connect-plus-progress', 'connect-plus-quiz-checkpoint', 'connect-plus-answer-count'] },
];
const ALL_KEYS = COURSES.flatMap(course => course.keys);
const LEGACY_BACKUP_KEY = 'mona-learning-hub-local-backup-v1';
const ACTIVE_OWNER_KEY = 'mona-learning-hub-active-progress-owner-v1';
const ACTIVE_RESET_KEY = 'mona-learning-hub-active-progress-reset-v1';
const app = document.getElementById('app');
const ADMIN_ROUTE = location.pathname.endsWith('/admin/') || location.pathname.endsWith('/admin/index.html');
let user = null;
let profile = null;
let isTeacher = false;
let teacherDashboard = null;
let courseControls = new Map();
let featuredStar = null;
let featuredPhoto = '';
let resetAt = null;
let mode = 'login';
let adminMode = localStorage.getItem('mona-teacher-activated') === 'yes' ? 'login' : 'activate';
let currentCourse = null;
let courseRows = new Map();
let legacy = new Map();
let saveTimer = null;
let saveChain = Promise.resolve();
let lastSnapshot = '';
let progressPoll = null;
let busy = false;
let message = '';
let messageType = 'info';

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}

function image(path) { return `${BASE}${path}`; }
function coursesForGrade(grade) { return COURSES.filter(course => course.grade === grade); }
// Each launch already loads cloud progress online; also fetch the current app shell.
function courseUrl(course) { return `${location.origin}/${encodeURIComponent(course.id)}/?portal=${Date.now()}`; }
function setMessage(value, type = 'info') { message = value; messageType = type; render(); }

function snapshot(course) {
  const data = {};
  for (const key of course.keys) {
    const value = localStorage.getItem(key);
    if (value !== null) data[key] = value;
  }
  return data;
}

function clearCourseKeys() {
  for (const key of ALL_KEYS) localStorage.removeItem(key);
}

function backupPreviousProgress() {
  let backup = {};
  try { backup = JSON.parse(localStorage.getItem(LEGACY_BACKUP_KEY) || '{}') || {}; }
  catch { backup = {}; }
  for (const course of COURSES) {
    const state = snapshot(course);
    if (!backup[course.id] && Object.keys(state).length) backup[course.id] = state;
  }
  try { localStorage.setItem(LEGACY_BACKUP_KEY, JSON.stringify(backup)); }
  catch { /* The original course keys remain available if storage is full. */ }
  return backup;
}

function seedProfile(course) {
  if (!profile) return;
  const student = profile.student_name;
  const grade = `Primary ${profile.grade}`;
  let saved = {};
  try { saved = JSON.parse(localStorage.getItem(course.keys[0]) || '{}') || {}; } catch { /* Use the account identity. */ }
  const identity = course.grade === 3
    ? { student, className: grade }
    : { name: student, className: grade, school: 'Al Andalus Private Schools', avatar: saved.avatar || '👧🏽' };
  // Grade 3 stores identity and progress together: never replace its saved progress.
  localStorage.setItem(course.keys[0], JSON.stringify({ ...saved, ...identity }));
}

async function loadAccount() {
  const { data: authData, error: authError } = await supabase.auth.getUser();
  if (authError || !authData.user) {
    user = null; profile = null; isTeacher = false; currentCourse = null; render(); return;
  }
  user = authData.user;
  const { data: teacherRole, error: teacherError } = await supabase.from('teacher_admins').select('user_id').eq('user_id',user.id).maybeSingle();
  if (teacherError) { setMessage('Could not verify account permissions. Please refresh.', 'error'); return; }
  isTeacher = Boolean(teacherRole);
  if (isTeacher) {
    if (!ADMIN_ROUTE) { location.replace(`${location.origin}${BASE}admin/`); return; }
    profile = null; currentCourse = null;
    teacherDashboard ||= createTeacherDashboard({ root: app, supabase, courses: COURSES, brand, signOut, base: BASE });
    await teacherDashboard.refresh();
    return;
  }
  if (ADMIN_ROUTE) { await supabase.auth.signOut(); user = null; profile = null; message = ''; render(); return; }
  const { data: student, error: profileError } = await supabase
    .from('student_profiles').select('student_name,grade,status,reset_at').eq('user_id', user.id).single();
  if (profileError || !student) {
    profile = null;
    setMessage('We could not load your student profile. Please contact Mrs. Mona Harb if this continues.', 'error');
    return;
  }
  profile = student;
  resetAt = student.reset_at;
  if (student.status !== 'active') { clearCourseKeys(); currentCourse = null; render(); return; }
  await supabase.rpc('mark_student_active');
  const [controlsResult, starResult] = await Promise.all([
    supabase.from('course_controls').select('app_id,grade,visible,open_units').eq('grade',student.grade),
    supabase.from('weekly_star').select('student_name,image_path,published').eq('singleton',true).maybeSingle(),
  ]);
  courseControls = new Map((controlsResult.data || []).map(row => [row.app_id,row]));
  featuredStar = starResult.data?.published ? starResult.data : null;
  featuredPhoto = '';
  if (featuredStar?.image_path) {
    const { data } = await supabase.storage.from('weekly-star').createSignedUrl(featuredStar.image_path,3600);
    featuredPhoto = data?.signedUrl || '';
  }
  const { data: rows, error: rowsError } = await supabase
    .from('app_progress').select('app_id,state,updated_at').eq('user_id', user.id);
  if (rowsError) {
    setMessage('We could not load your saved progress. Please refresh the page.', 'error');
    return;
  }
  courseRows = new Map((rows ?? []).filter(row => row.state && Object.keys(row.state).length > 0).map(row => [row.app_id, row]));
  if (resetAt && localStorage.getItem(ACTIVE_RESET_KEY) !== resetAt) {
    clearCourseKeys(); localStorage.removeItem(LEGACY_BACKUP_KEY);
  }
  if (localStorage.getItem(ACTIVE_OWNER_KEY) === user.id && localStorage.getItem(ACTIVE_RESET_KEY) === (resetAt || '')) {
    for (const course of coursesForGrade(profile.grade)) {
      const pending = snapshot(course);
      if (!hasLearningProgress(course, pending)) continue;
      const previous = courseRows.get(course.id);
      const combined = mergeProgress(course, pending, previous?.state || {});
      const { data: restored, error: restoreError } = await supabase.from('app_progress').upsert({
        user_id: user.id, app_id: course.id, state: combined, updated_at: new Date().toISOString(),
      }, { onConflict: 'user_id,app_id' }).select('app_id,state,updated_at').single();
      if (restoreError || !restored || Object.keys(combined).some(key => restored.state?.[key] !== combined[key])) {
        setMessage('Your latest work is still on this device. Reconnect and refresh to save it before opening lessons.', 'error');
        return;
      }
      courseRows.set(course.id, restored);
    }
  }
  const previous = backupPreviousProgress();
  legacy = new Map(coursesForGrade(profile.grade).map(course => [course.id, previous[course.id] || {}]));
  clearCourseKeys();
  localStorage.removeItem(ACTIVE_OWNER_KEY);
  localStorage.removeItem(ACTIVE_RESET_KEY);
  message = '';
  render();
}

async function performSave(course) {
  if (!user || !profile || course.grade !== profile.grade) return false;
  const { data: latestProfile, error: accessError } = await supabase.from('student_profiles')
    .select('status,reset_at').eq('user_id', user.id).single();
  if (accessError || !latestProfile || latestProfile.status !== 'active') {
    updateSaveBadge('Account access changed. Refresh the page.'); return false;
  }
  if (latestProfile.reset_at && latestProfile.reset_at !== resetAt) {
    resetAt = latestProfile.reset_at;
    document.querySelector('#course-frame')?.remove(); currentCourse = null;
    clearCourseKeys(); localStorage.removeItem(LEGACY_BACKUP_KEY);
    localStorage.removeItem(ACTIVE_OWNER_KEY); localStorage.removeItem(ACTIVE_RESET_KEY);
    courseRows.clear(); legacy.clear();
    message = 'Mrs. Mona Harb reset your progress. Your learning path is ready to begin again.';
    messageType = 'info'; render(); return false;
  }
  const state = snapshot(course);
  if (Object.keys(state).length === 0) {
    updateSaveBadge('No new progress to save yet');
    return false;
  }
  const { data: latest, error: readError } = await supabase.from('app_progress')
    .select('app_id,state,updated_at').eq('user_id', user.id).eq('app_id', course.id).maybeSingle();
  if (readError) {
    updateSaveBadge('Could not verify cloud progress. Check your connection.');
    return false;
  }
  const merged = mergeProgress(course, state, latest?.state || {});
  const { data: written, error } = await supabase.from('app_progress').upsert({
    user_id: user.id, app_id: course.id, state: merged, updated_at: new Date().toISOString(),
  }, { onConflict: 'user_id,app_id' }).select('app_id,state,updated_at').single();
  if (error || !written || Object.keys(merged).some(key => written.state?.[key] !== merged[key])) {
    updateSaveBadge('Could not save. Check your connection.');
    message = 'Your progress could not be saved. Check your internet connection before leaving the lesson.';
    messageType = 'error';
    return false;
  }
  courseRows.set(course.id, written);
  lastSnapshot = JSON.stringify(state);
  updateSaveBadge(hasLearningProgress(course, written.state) ? 'Progress saved to cloud ✓' : 'Account saved · Start a lesson to earn points');
  return true;
}

function saveCourse(course) {
  const pending = saveChain.then(() => performSave(course));
  saveChain = pending.catch(() => {
    updateSaveBadge('Could not save. Check your connection.');
    return false;
  });
  return pending;
}

function updateSaveBadge(value) {
  const node = document.querySelector('#save-status');
  if (node) node.textContent = value;
}

function queueSave() {
  if (!currentCourse) return;
  updateSaveBadge('Saving progress...');
  clearTimeout(saveTimer);
  const course = currentCourse;
  saveTimer = setTimeout(() => { if (currentCourse?.id === course.id) void saveCourse(course); }, 350);
}

function stopProgressPoll() {
  if (progressPoll) clearInterval(progressPoll);
  progressPoll = null;
}

function startProgressPoll(course) {
  stopProgressPoll();
  lastSnapshot = JSON.stringify(snapshot(course));
  progressPoll = setInterval(() => {
    if (currentCourse?.id !== course.id) return;
    const now = JSON.stringify(snapshot(course));
    if (now !== lastSnapshot) { lastSnapshot = now; queueSave(); }
  }, 1500);
}

window.addEventListener('storage', event => {
  if (currentCourse && currentCourse.keys.includes(event.key)) queueSave();
});
window.addEventListener('message', event => {
  if (event.origin !== location.origin || !currentCourse || event.data?.type !== 'mona:progress-changed') return;
  const frame = document.querySelector('#course-frame');
  if (event.source !== frame?.contentWindow || event.data.appId !== currentCourse.id) return;
  queueSave();
});
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'hidden' && currentCourse) {
    clearTimeout(saveTimer);
    void saveCourse(currentCourse);
  }
});

async function closeCourse() {
  if (!currentCourse) return;
  const course = currentCourse;
  clearTimeout(saveTimer);
  stopProgressPoll();
  const frame = document.querySelector('#course-frame');
  if (frame) frame.style.visibility = 'hidden';
  const saved = await saveCourse(course);
  if (!saved && hasLearningProgress(course, snapshot(course))) {
    if (frame) frame.style.visibility = '';
    startProgressPoll(course);
    updateSaveBadge('Save failed · Check connection before leaving');
    return false;
  }
  if (frame) frame.remove();
  currentCourse = null;
  clearCourseKeys();
  localStorage.removeItem(ACTIVE_OWNER_KEY);
  localStorage.removeItem(ACTIVE_RESET_KEY);
  render();
  return true;
}

async function openCourse(id) {
  const course = COURSES.find(item => item.id === id);
  if (!course || !profile || course.grade !== profile.grade || !courseControls.get(id)?.visible || profile.status !== 'active') return;
  if (currentCourse && !(await closeCourse())) return;
  if (currentCourse) return;
  const { data: freshRow, error: freshError } = await supabase.from('app_progress')
    .select('app_id,state,updated_at').eq('user_id',user.id).eq('app_id',course.id).maybeSingle();
  if (freshError) { setMessage('Could not load cloud progress. Check your connection and try again.', 'error'); return; }
  if (freshRow) courseRows.set(course.id, freshRow);
  else courseRows.delete(course.id);
  clearCourseKeys();
  const row = courseRows.get(course.id);
  if (row?.state && typeof row.state === 'object' && Object.keys(row.state).length > 0) {
    for (const key of course.keys) {
      const value = row.state[key];
      if (typeof value === 'string') localStorage.setItem(key, value);
    }
  }
  seedProfile(course);
  currentCourse = course;
  localStorage.setItem(ACTIVE_OWNER_KEY, user.id);
  localStorage.setItem(ACTIVE_RESET_KEY, resetAt || '');
  localStorage.setItem(`mona-unit-control-${course.id}`,JSON.stringify({openUnits:courseControls.get(course.id)?.open_units || [1,2,3,4,5,6],updatedAt:Date.now()}));
  message = '';
  render();
  startProgressPoll(course);
}

async function importLegacy(id) {
  const course = COURSES.find(item => item.id === id);
  const state = legacy.get(id);
  if (!course || !state || !profile || course.grade !== profile.grade || courseRows.has(id)) return;
  clearCourseKeys();
  for (const [key, value] of Object.entries(state)) if (course.keys.includes(key)) localStorage.setItem(key, value);
  const saved = await saveCourse(course);
  clearCourseKeys();
  if (saved) { legacy.delete(id); render(); }
}

async function signOut() {
  if (currentCourse && !(await closeCourse())) return;
  await supabase.auth.signOut();
  clearCourseKeys();
  user = null; profile = null; isTeacher = false; teacherDashboard = null; currentCourse = null; courseRows.clear(); legacy.clear();
  mode = 'login'; message = ''; render();
}

function brand() {
  return `<div class="brand"><span class="brand-mark"><img src="${image('school-logo.png')}" alt="Al Andalus Private Schools logo" /></span><span class="brand-name"><b>Al Andalus Private Schools</b><small>ENGLISH LEARNING GARDEN</small></span></div>`;
}

function notice() { return message ? `<div class="notice ${messageType}" role="status">${escapeHtml(message)}</div>` : ''; }

function renderAuth() {
  app.innerHTML = `<main class="auth-shell">
    <section class="auth-content">
      <header class="site-header">${brand()}<span class="teacher-pill">With <b>Mrs. Mona Harb</b> ✦</span></header>
      <div class="auth-copy"><span class="eyebrow"><span>✦</span> ${ADMIN_ROUTE?'TEACHER ADMINISTRATION':'ENGLISH GARDEN · TERM 1'}</span>
        <h1>${ADMIN_ROUTE?'Welcome back,<br><em>Mrs. Mona!</em>':'Your <em>English</em> adventure<br>starts here!'}</h1>
        <p>${ADMIN_ROUTE?'Sign in to guide your students and manage the learning garden.':'A world of stories, words and joyful challenges, made for Grade 3 and Grade 4 girls.'}</p>
      </div>
      <div class="auth-card">
        ${ADMIN_ROUTE?'':`<div class="auth-tabs" role="tablist"><button id="login-tab" class="${mode === 'login' ? 'active' : ''}" type="button">Log in</button><button id="signup-tab" class="${mode === 'signup' ? 'active' : ''}" type="button">Create account</button></div>`}
        ${ADMIN_ROUTE?`<div class="auth-tabs"><button id="activate-tab" type="button" class="${adminMode==='activate'?'active':''}">Activate account</button><button id="teacher-login-tab" type="button" class="${adminMode==='login'?'active':''}">Teacher log in</button></div>`:''}
        <div class="auth-card-head"><span class="sparkle">✿</span><div><h2>${ADMIN_ROUTE?(adminMode==='activate'?'Activate your account':'Welcome back, Mrs. Mona!'):mode === 'signup' ? 'Join our garden' : 'Welcome back!'}</h2><p>${ADMIN_ROUTE?(adminMode==='activate'?'Enter your email, one-time code, and new password':'Sign in with your email and password'):mode === 'signup' ? 'A few details, then your adventure begins' : 'Open your lessons and saved progress'}</p></div></div>
        ${notice()}
        <form id="auth-form">
          ${mode === 'signup' ? `<label for="student-name">Student name</label><input id="student-name" name="student_name" type="text" autocomplete="name" maxlength="80" minlength="2" placeholder="Your name" required />
          <label for="grade">Grade</label><div class="grade-select"><select id="grade" name="grade" required><option value="" selected disabled>Choose your grade</option><option value="3">Grade 3</option><option value="4">Grade 4</option></select><span>⌄</span></div>` : ''}
          <label for="email">Email address</label><input id="email" name="email" type="email" autocomplete="email" inputmode="email" placeholder="name@example.com" required />
          ${ADMIN_ROUTE&&adminMode==='activate'?`<label for="activation-code">Activation code</label><input id="activation-code" name="code" type="text" inputmode="text" autocomplete="one-time-code" minlength="12" maxlength="12" pattern="[A-Za-z0-9]{12}" placeholder="12-character code" required />`:''}
          <label for="password">${ADMIN_ROUTE&&adminMode==='activate'?'New password':'Password'}</label><input id="password" name="password" type="password" autocomplete="${ADMIN_ROUTE&&adminMode==='activate'||mode==='signup'?'new-password':'current-password'}" minlength="${ADMIN_ROUTE&&adminMode==='activate'?8:6}" placeholder="At least ${ADMIN_ROUTE&&adminMode==='activate'?8:6} characters" required />
          <button class="primary-btn" type="submit" ${busy ? 'disabled' : ''}>${busy ? 'Just a moment...' : ADMIN_ROUTE ? adminMode==='activate'?'Activate teacher account  →':'Open teacher dashboard  →' : mode === 'signup' ? 'Create my account  →' : 'Enter my garden  →'}</button>
        </form>
        <p class="form-foot">${ADMIN_ROUTE?`<a href="${BASE}">← Back to the student portal</a>`:mode === 'signup' ? 'Already have an account? <button id="switch-login" type="button">Log in</button>' : 'New here? <button id="switch-signup" type="button">Create an account</button>'}</p>
      </div>
      <div class="auth-bottom"><span>✦ Learn your way</span><span>✦ Save your progress</span><span>✦ Made for you</span></div>
    </section>
    <section class="auth-visual" aria-label="Egyptian girls discovering English"><img src="${image('english-hero.png')}" alt="Three young Egyptian girls discovering English through a storybook" /></section>
  </main>`;
  if (!ADMIN_ROUTE) {
    document.querySelector('#login-tab').onclick = () => { mode = 'login'; message = ''; render(); };
    document.querySelector('#signup-tab').onclick = () => { mode = 'signup'; message = ''; render(); };
  }
  else {
    document.querySelector('#activate-tab').onclick = () => { adminMode='activate'; message=''; render(); };
    document.querySelector('#teacher-login-tab').onclick = () => { adminMode='login'; message=''; render(); };
  }
  document.querySelector('#switch-login')?.addEventListener('click', () => { mode = 'login'; message = ''; render(); });
  document.querySelector('#switch-signup')?.addEventListener('click', () => { mode = 'signup'; message = ''; render(); });
  document.querySelector('#auth-form').addEventListener('submit', submitAuth);
}

async function submitAuth(event) {
  event.preventDefault();
  if (busy) return;
  const form = new FormData(event.currentTarget);
  const email = String(form.get('email') ?? '').trim();
  const password = String(form.get('password') ?? '');
  busy = true; message = ''; render();
  try {
    if (ADMIN_ROUTE && adminMode === 'activate') {
      const code = String(form.get('code') ?? '').trim();
      const { data, error } = await supabase.functions.invoke('teacher-admin', { body: { action: 'activate', email, code, password } });
      if (error) {
        let detail = error.message;
        try { detail = (await error.context.json()).error || detail; } catch { /* Network error. */ }
        throw new Error(detail);
      }
      if (!data?.ok) throw new Error('Activation could not be completed.');
      localStorage.setItem('mona-teacher-activated','yes');
      const { error: loginError } = await supabase.auth.signInWithPassword({ email, password });
      if (loginError) throw loginError;
      adminMode='login'; await loadAccount();
    } else if (!ADMIN_ROUTE && mode === 'signup') {
      const name = String(form.get('student_name') ?? '').trim();
      const grade = Number(form.get('grade'));
      if (name.length < 2 || ![3, 4].includes(grade)) throw new Error('Enter your name and choose Grade 3 or Grade 4.');
      const { data, error } = await supabase.auth.signUp({ email, password, options: {
        data: { student_name: name, grade: String(grade) },
        emailRedirectTo: `${location.origin}${BASE}`,
      } });
      if (error) throw error;
      if (data.session) await loadAccount();
      else { mode = 'login'; setMessage('Account created. Please check your email for a confirmation link, then log in.', 'success'); }
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      await loadAccount();
      if (!isTeacher && profile?.status === 'active') void supabase.from('student_logins').insert({user_id:user.id});
    }
  } catch (error) {
    const text = String(error?.message ?? error);
    setMessage(text.includes('Invalid login') ? 'The email address or password is incorrect.' :
      text.includes('Email not confirmed') ? 'Please confirm your email address first.' : text, 'error');
  } finally { busy = false; render(); }
}

function card(course) {
  const row = courseRows.get(course.id);
  const oldState = legacy.get(course.id);
  const canImport = !row && oldState && Object.keys(oldState).length > 0;
  return `<article class="course-card ${course.color}"><div class="course-top"><span class="course-icon">${course.icon}</span><span class="course-tag">${course.badge}</span></div>
    <div class="course-copy"><h3>${course.title}</h3><p>${course.subtitle}</p></div>
    <div class="course-bottom"><span class="saved-state">${row && hasLearningProgress(course, row.state) ? '✓ Progress saved' : 'A new adventure'}</span><button type="button" class="course-open" data-course="${escapeHtml(course.id)}">${row && hasLearningProgress(course, row.state) ? 'Continue learning' : 'Start learning'} <span>→</span></button></div>
    ${canImport ? `<button type="button" class="import-link" data-import="${escapeHtml(course.id)}">Have progress on this device? Import it</button>` : ''}
  </article>`;
}

function renderDashboard() {
  const courses = coursesForGrade(profile.grade).filter(course => courseControls.get(course.id)?.visible);
  app.innerHTML = `<main class="dashboard"><header class="dash-header"><div class="dash-inner">${brand()}<div class="dash-user"><span class="user-avatar">${escapeHtml(profile.student_name.charAt(0))}</span><div><b>${escapeHtml(profile.student_name)}</b><small>Grade ${profile.grade}</small></div><button id="logout" type="button">Log out</button></div></div></header>
    <div class="dash-wrap"><section class="welcome-panel"><div><span class="eyebrow">✦ HELLO, SUPERSTAR!</span><h1>Welcome, ${escapeHtml(profile.student_name)} <span>👋</span></h1><p>Choose your adventure and pick up where you left off.</p><span class="grade-badge">⭐ Grade ${profile.grade}</span></div><div class="welcome-doodle" aria-hidden="true">A<span>✦</span>B<br><small>📚</small>C</div></section>
    ${featuredStar?`<section class="student-star"><div class="student-star-photo">${featuredPhoto?`<img src="${escapeHtml(featuredPhoto)}" alt="Star of the week">`:'★'}</div><div><span>✦ STAR OF THE WEEK</span><h2>${escapeHtml(featuredStar.student_name)}</h2><p>Keep shining and inspiring us all!</p></div><div class="student-star-sparkle">✦</div></section>`:''}
    ${notice()}<div class="section-heading"><div><span>✦ YOUR LEARNING PATH</span><h2>Your learning sites</h2></div><p>${courses.length} ${courses.length===1?'site':'sites'} chosen for your grade</p></div>
    <section class="course-grid">${courses.map(card).join('') || '<p class="course-empty">Your learning sites are closed for now. Please check back soon.</p>'}</section><div class="dash-footer"><span>Al Andalus Private Schools</span><span>Made with care by Mrs. Mona Harb ♡</span></div></div></main>`;
  document.querySelector('#logout').onclick = signOut;
  document.querySelectorAll('[data-course]').forEach(button => button.onclick = () => openCourse(button.dataset.course));
  document.querySelectorAll('[data-import]').forEach(button => button.onclick = () => importLegacy(button.dataset.import));
}

function renderPlayer() {
  const course = currentCourse;
  app.innerHTML = `<main class="player"><header class="player-bar"><button id="back" type="button">← Back to my sites</button><div><strong>${escapeHtml(course.title)}</strong><small>Mrs. Mona Harb · Grade ${profile.grade}</small></div><span id="save-status">Your progress saves automatically</span></header><iframe id="course-frame" title="${escapeHtml(course.title)}" src="${courseUrl(course)}" allow="fullscreen; clipboard-read; clipboard-write"></iframe></main>`;
  document.querySelector('#back').onclick = closeCourse;
}

function render() {
  if (isTeacher && teacherDashboard) teacherDashboard.render();
  else if (profile?.status === 'suspended') app.innerHTML = `<main class="blocked-account">${brand()}<h1>Account paused</h1><p>Please contact Mrs. Mona Harb to restore access.</p><button id="logout">Log out</button></main>`, document.querySelector('#logout').onclick = signOut;
  else if (!user || !profile) renderAuth();
  else if (currentCourse) renderPlayer();
  else renderDashboard();
}

supabase.auth.onAuthStateChange((event) => {
  if (event === 'SIGNED_OUT') { user = null; profile = null; isTeacher = false; teacherDashboard = null; currentCourse = null; clearCourseKeys(); render(); }
});

render();
loadAccount().catch(error => setMessage(`Could not connect to the database: ${error.message}`, 'error'));
