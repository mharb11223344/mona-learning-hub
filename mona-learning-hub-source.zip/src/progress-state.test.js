import test from 'node:test';
import assert from 'node:assert/strict';
import { hasLearningProgress, mergeProgress } from './progress-state.js';

const courses = {
  english3: { id: 'english3-1termapp', keys: ['monaPrimary3AppV1'] },
  plus3: { id: 'connectplus3-term1app', keys: ['connectPlus3MonaHarbV2'] },
  english4: { id: 'connectplus4-term1app', keys: ['mona-primary4-profile-v1', 'mona-primary4-progress-v1'] },
  plus4: { id: 'Plus4app-term1', keys: ['connect-plus-student', 'connect-plus-progress'] },
};

test('returning Grade 3 students keep cloud points after a fresh start writes zeros', () => {
  for (const course of [courses.english3, courses.plus3]) {
    const key = course.keys[0];
    const saved = { [key]: JSON.stringify({ student: 'Learner', xp: 80, solved: 8, completed: ['1-1'], lastLesson: '2-1', quizProgress: { a: { index: 4 } } }) };
    const incoming = { [key]: JSON.stringify({ student: 'Learner', xp: 0, solved: 0, completed: [], lastLesson: '1-1', quizProgress: {} }) };
    const merged = mergeProgress(course, incoming, saved);
    const result = JSON.parse(merged[key]);
    assert.equal(result.xp, 80);
    assert.equal(result.solved, 8);
    assert.deepEqual(result.completed, ['1-1']);
    assert.equal(result.quizProgress.a.index, 4);
    assert.equal(result.lastLesson, '2-1');
    assert.equal(hasLearningProgress(course, merged), true);
  }
});

test('Grade 4 English retains scores and stars when local progress is incomplete', () => {
  const key = 'mona-primary4-progress-v1';
  const saved = { [key]: JSON.stringify({ xp: 120, completedLessons: ['l1'], stars: { l1: 3 }, bestScores: { l1: 90 } }) };
  const incoming = { [key]: JSON.stringify({ xp: 0, completedLessons: [], stars: {}, bestScores: {} }) };
  const result = JSON.parse(mergeProgress(courses.english4, incoming, saved)[key]);
  assert.equal(result.xp, 120);
  assert.equal(result.stars.l1, 3);
  assert.equal(result.bestScores.l1, 90);
  assert.deepEqual(result.completedLessons, ['l1']);
});

test('Connect Plus 4 retains best quiz points and answer count', () => {
  const saved = { 'connect-plus-progress': JSON.stringify({ u1l1: { score: 220, total: 300 } }), 'connect-plus-answer-count': '12' };
  const incoming = { 'connect-plus-progress': JSON.stringify({ u1l1: { score: 80, total: 300 } }), 'connect-plus-answer-count': '1' };
  const merged = mergeProgress(courses.plus4, incoming, saved);
  assert.equal(JSON.parse(merged['connect-plus-progress']).u1l1.score, 220);
  assert.equal(merged['connect-plus-answer-count'], '12');
  assert.equal(hasLearningProgress(courses.plus4, merged), true);
});

test('a profile alone does not show a misleading saved-progress badge', () => {
  assert.equal(hasLearningProgress(courses.english3, { monaPrimary3AppV1: JSON.stringify({ student: 'Learner' }) }), false);
  assert.equal(hasLearningProgress(courses.plus4, { 'connect-plus-student': JSON.stringify({ name: 'Learner' }) }), false);
});
