function parse(value, fallback = {}) {
  try { return JSON.parse(value) ?? fallback; } catch { return fallback; }
}

function number(value) { return Number.isFinite(Number(value)) ? Number(value) : 0; }
function unique(values) { return [...new Set(values)]; }

export function hasLearningProgress(course, state = {}) {
  if (course.id === 'Plus4app-term1') {
    return Object.keys(parse(state['connect-plus-progress'])).length > 0 ||
      number(state['connect-plus-answer-count']) > 0 ||
      number(parse(state['connect-plus-quiz-checkpoint']).questionIndex) > 0;
  }
  const key = course.id === 'connectplus4-term1app' ? 'mona-primary4-progress-v1' : course.keys[0];
  const value = parse(state[key]);
  return number(value.xp) > 0 || number(value.solved) > 0 || number(value.questionsAnswered) > 0 ||
    (Array.isArray(value.completed) && value.completed.length > 0) ||
    (Array.isArray(value.completedLessons) && value.completedLessons.length > 0) ||
    Object.values(value.quizProgress || {}).some(item => number(item?.index) > 0 || number(item?.answered) > 0);
}

export function mergeProgress(course, incoming, saved = {}) {
  const merged = { ...saved, ...incoming };
  if (course.id === 'english3-1termapp' || course.id === 'connectplus3-term1app') {
    const key = course.keys[0];
    const local = parse(incoming[key]);
    const cloud = parse(saved[key]);
    if (!saved[key]) return merged;
    const result = { ...cloud, ...local };
    if (number(local.solved) < number(cloud.solved)) {
      for (const field of ['lastRoute', 'lastLesson', 'lastSection', 'lastQuestion', 'activeQuiz']) {
        if (cloud[field] !== undefined) result[field] = cloud[field];
      }
    }
    for (const field of ['xp', 'coins', 'stars', 'solved', 'correct']) result[field] = Math.max(number(cloud[field]), number(local[field]));
    for (const field of ['completed', 'readerCompleted', 'badges']) {
      if (Array.isArray(cloud[field]) || Array.isArray(local[field])) result[field] = unique([...(cloud[field] || []), ...(local[field] || [])]);
    }
    const progress = { ...cloud.quizProgress, ...local.quizProgress };
    for (const [quiz, old] of Object.entries(cloud.quizProgress || {})) {
      const next = progress[quiz];
      if (!next || number(old.answered ?? old.index) > number(next.answered ?? next.index)) progress[quiz] = old;
    }
    result.quizProgress = progress;
    merged[key] = JSON.stringify(result);
  } else if (course.id === 'connectplus4-term1app') {
    const key = 'mona-primary4-progress-v1';
    const local = parse(incoming[key]);
    const cloud = parse(saved[key]);
    if (saved[key]) {
      const result = { ...cloud, ...local };
      if (number(local.questionsAnswered) < number(cloud.questionsAnswered)) {
        for (const field of ['lastUnitId', 'lastLessonId', 'lastView', 'quizCheckpoint']) {
          if (cloud[field] !== undefined) result[field] = cloud[field];
        }
      }
      for (const field of ['xp', 'questionsAnswered']) result[field] = Math.max(number(cloud[field]), number(local[field]));
      result.stars = { ...cloud.stars, ...local.stars };
      for (const [quiz, stars] of Object.entries(cloud.stars || {})) result.stars[quiz] = Math.max(number(stars), number(result.stars[quiz]));
      for (const field of ['completedLessons', 'badges']) {
        if (Array.isArray(cloud[field]) || Array.isArray(local[field])) result[field] = unique([...(cloud[field] || []), ...(local[field] || [])]);
      }
      result.bestScores = { ...cloud.bestScores, ...local.bestScores };
      for (const [quiz, score] of Object.entries(cloud.bestScores || {})) result.bestScores[quiz] = Math.max(number(score), number(result.bestScores[quiz]));
      merged[key] = JSON.stringify(result);
    }
  } else if (course.id === 'Plus4app-term1') {
    const key = 'connect-plus-progress';
    const local = parse(incoming[key]);
    const cloud = parse(saved[key]);
    const result = { ...cloud, ...local };
    for (const [quiz, previous] of Object.entries(cloud)) {
      if (number(previous?.score) > number(result[quiz]?.score)) result[quiz] = previous;
    }
    if (Object.keys(result).length) merged[key] = JSON.stringify(result);
    const count = Math.max(number(incoming['connect-plus-answer-count']), number(saved['connect-plus-answer-count']));
    if (count) merged['connect-plus-answer-count'] = String(count);
    if (incoming['connect-plus-quiz-checkpoint'] && saved['connect-plus-quiz-checkpoint']) {
      const localQuiz = parse(incoming['connect-plus-quiz-checkpoint']);
      const cloudQuiz = parse(saved['connect-plus-quiz-checkpoint']);
      if (localQuiz.quizId === cloudQuiz.quizId && number(localQuiz.questionIndex) < number(cloudQuiz.questionIndex)) {
        merged['connect-plus-quiz-checkpoint'] = saved['connect-plus-quiz-checkpoint'];
      }
    }
    // A completed quiz removes its checkpoint. Keep a cloud checkpoint only when no newer answer was recorded.
    if (!incoming['connect-plus-quiz-checkpoint'] && saved['connect-plus-quiz-checkpoint'] && !incoming[key]) merged['connect-plus-quiz-checkpoint'] = saved['connect-plus-quiz-checkpoint'];
  }
  return merged;
}
