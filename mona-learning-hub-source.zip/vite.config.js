import { defineConfig } from 'vite';
import { resolve } from 'node:path';

export default defineConfig({
  base: '/mona-learning-hub/',
  build: { outDir: 'dist', assetsDir: '', rollupOptions: { input: {
    main: resolve(import.meta.dirname, 'index.html'),
    admin: resolve(import.meta.dirname, 'admin/index.html'),
  } } },
});
