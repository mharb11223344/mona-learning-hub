import { defineConfig } from 'vite';

export default defineConfig({
  base: '/mona-learning-hub/',
  build: { outDir: 'dist', assetsDir: '' },
});
